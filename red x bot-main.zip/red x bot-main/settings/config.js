
// 漏 2025 Abdul Rehman Rajpoot. All Rights Reserved.
// respect the work, don鈥檛 just copy-paste.

const fs = require('fs')

const config = {
    owner: "Abdul Rehman Rajpoot",
    botNumber: "923446044324",
    setPair: "RedRAID1",
    thumbUrl: "<a href="https://ibb.co/pr6Z18vb"><img src="https://i.ibb.co/pr6Z18vb/Snapchat-731731418.jpg" alt="Snapchat-731731418" border="0"></a>",
    session: "sessions",
    status: {
        public: true,
        terminal: true,
        reactsw: false
    },
    message: {
        owner: "no, this is for owners only",
        group: "this is for groups only",
        admin: "this command is for admin only",
        private: "this is specifically for private chat"
    },
    mess: {
        owner: 'This command is only for the bot owner!',
        done: 'Mode changed successfully!',
        error: 'Something went wrong!',
        wait: 'Please wait...'
    },
    settings: {
        title: "Red X Bot",
        packname: 'WA-BASE',
        description: "this script was created by Abdul rehman Rajpoot",
        author: 'https://github.com/AbdulRehman19721986',
        footer: "饾棈饾柧饾梾饾柧饾梹饾棆饾柡饾梿: @AbdulRehman19721986"
    },
    newsletter: {
        name: "Red X Bot",
        id: "0@newsletter"
    },
    api: {
        baseurl: "https://hector-api.vercel.app/",
        apikey: "hector"
    },
    sticker: {
        packname: "Red X Bot",
        author: "ABdul Rehman Rajpoot"
    }
}

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
